#include "MyProgressBar.h"

MyProgressBar::MyProgressBar(QWidget *parent=0):QProgressBar(parent)
{
}





